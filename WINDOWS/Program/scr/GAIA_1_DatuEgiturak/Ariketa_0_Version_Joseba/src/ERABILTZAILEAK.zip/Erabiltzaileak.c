
#include <stdio.h>
#include <string.h>

#include "orokorrak.h"
#include "erabiltzaileak.h"

int ERABILTZAILEAK_sortu_(ERABILTZAILEA erabil[], int kop) {
	
	strcpy(erabil[0].izena, "admin");
	strcpy(erabil[0].password, "qwerty");
	erabil[0].mota = ADMIN;


	strcpy(erabil[0].izena, "joseba");
	strcpy(erabil[0].password, "123");
	erabil[0].mota = EROSLE;


	strcpy(erabil[0].izena, "irati");
	strcpy(erabil[0].password, "321");
	erabil[0].mota = EROSLE;


}