#ifndef FUNTZIOAK_H
#define FUNTZIOAK_H

typedef struct {

	float reala;
	float irudikaria;

}KONPLEXUA;

float kalkulatuModulua(KONPLEXUA zenbakia);
float alderantzizkoaKalkulatu(float modulua);



#endif // !FUNZTIOAK_H
