#ifndef FUNTZIOAK_H
#define FUNTZIOAK_H


void astekoEgunakPantailaratu(char *asteko_egunak[]);
void egunaPaintailaratu(int eguna, char *asteko_egunak[]);


#endif // !FUNTZIOAK_H
