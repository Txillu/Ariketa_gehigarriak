
#include<stdio.h>
#include "ikasleak.h"

int main() {
	int aux;
	/*
	
		============================================
		Menu
		============================================
		1. Gehitu ikasle baten notak
		2. Borratu ikasle baten notak
		3. Eguneratu ikasle baten notak
		4. Bistaratu ikasle guztien notak
		5. Kalkulatu aukeratutako ikasleen noten batazbestekoa
		6. Bistaratu bukaerako nota finalik altuena duen ikaslearen informazioa
		7. Bistaratu bukaerako nota finalik baxuena duen ikaslearen informazioa
		8. ID bidez ikasle bat bilatu
		9. Informazioa nota finalaren arabera ordenaturik bistaratu
		Sartu aukera bat:
		Oharra: Ikasle guztien datuak egituraz osatutako array batean goredeko
		dira.
		*/


	//PROGRANA
	 MENUA_erakutsi();

	//BUKAERA
	printf("Sakatu return bukatzeko....");
	aux = getchar();


	return 0;
}