#ifndef FITXATEGI_H
#define FITXAYEGI_H

#define IRAKURRI_ERREALAK "errealak.txt"

int zenbakiak_Irakurri(float zenbakiak[]);

#endif // !FITXATEGI_H
